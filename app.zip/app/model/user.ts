export /**
 * User */
class User{
    constructor(private username:string,private password:string) {
        
    }
}