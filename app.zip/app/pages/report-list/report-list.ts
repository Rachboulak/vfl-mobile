import { Component, OnInit } from '@angular/core';

import { NavController, NavParams, Page } from 'ionic-angular';

import { ReportService, Report } from '../../providers/report-service/report-service';
//import { ReportDetailPage } from '../report-detail/report-detail';


@Component({
  templateUrl: 'build/pages/report-list/report-list.html',
  providers:[ReportService]
})
export class ReportListPage implements OnInit {
  reports: Report[];
  //reportService;
  private start:number=0;
  constructor(public navCtrl: NavController, private navparams:NavParams, public reportService: ReportService) {
    //reportService.getAllReports();
    this.reportService = reportService;
    //this.loadReports();
  }

  doInfinite(infiniteScroll) {
     console.log('doInfinite, start is currently ', this.start);
     console.log('doInfinite, infiniteScroll ', infiniteScroll);
     this.start+=2;
    // this.loadReports();
     this.loadPeople().then(()=>{
       infiniteScroll.complete();
     });
     /* setTimeout(() => {
      for (var i = 0; i < 30; i++) {
        this.reports.push( new Report('line', 'site', 'agency', new Date(), i) );
      }

      console.log('Async operation has ended');
      infiniteScroll.complete();
    }, 500);*/
     
  }

  loadPeople() {
    
    this.reports.push(new Report('line', 'site', 'agency', new Date(), 1));

    /*this.reportService.load(
      this.start,
      (data) => {
         console.log("load reports", data);
        this.reports = [];
        if (data.rows.length > 0) {
          console.log(JSON.stringify(data.rows));
          for (var i = 0; i < data.rows.length; i++) {
            let item = data.rows.item(i);
            this.reports.push(new Report(item.line, item.site, item.agency,item.date, item.id));
          }
           console.log(' Load reports ',this.reports );
        }
      });*/
    return new Promise(resolve => {
      
      this.reportService.load(this.start)
      .then(data => {
        for(let person of data) {
          this.reports.push(person);
        }
        
        resolve(true);
        
      });
            
    });

  }

  ngOnInit() {
    this.loadReports();
  }
/*  goToReportDetail(speakerName: string) {
    this.navCtrl.push(ReportDetailPage, speakerName);
  }*/
  private loadReports() {
    console.log("ReportListPage loadReports");
    this.reports = [];
    var min= this.start;
    this.start+=10;
    for (var index = min; index < this.start; index++) {
      //var element = array[index];
      this.reports.push(new Report('line', 'site', 'agency', new Date(), index));
    }
    
    /*this.reportService.getAllReports(
      (data) => {
         console.log("ReportListPage load reports 1 ", data);
        this.reports = [];
        if (data.rows.length > 0) {
          console.log(JSON.stringify(data.rows));
          for (var i = 0; i < data.rows.length; i++) {
            let item = data.rows.item(i);
            this.reports.push(new Report(item.line, item.site, item.agency,item.date, item.id));
          }
           console.log('ReportListPage Load reports 2',this.reports );
        }*
      });*/
     
      
  }
}
